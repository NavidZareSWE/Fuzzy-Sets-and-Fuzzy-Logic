#!/usr/bin/env python3
"""
Interactive Fuzzy Time Series Prediction Interface
===================================================
This script provides an interactive command-line interface for making
predictions using trained FTS models.

Usage:
    python run_interactive.py [--dataset DATASET] [--order ORDER] [--partitions N] [--mf-type TYPE]

Arguments:
    --dataset: Dataset to use ('mackey_glass', 'specimens', 'influenza_a', 'influenza_b')
    --order: Model order (default: 3)
    --partitions: Number of fuzzy partitions (default: 11)
    --mf-type: Membership function type ('triangular', 'gaussian', 'trapezoidal', 'bell')
"""

import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fts_core import FuzzyTimeSeries, MembershipFunctionType
from fts_data import DataLoader
from fts_interface import FTSPredictor, InteractiveCLI


def main():
    parser = argparse.ArgumentParser(
        description='Interactive Fuzzy Time Series Prediction',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python run_interactive.py
    python run_interactive.py --dataset mackey_glass --order 3 --partitions 11
    python run_interactive.py --mf-type gaussian
        """
    )
    
    parser.add_argument(
        '--dataset', '-d',
        choices=['mackey_glass', 'specimens', 'influenza_a', 'influenza_b'],
        default='mackey_glass',
        help='Dataset to use for training (default: mackey_glass)'
    )
    
    parser.add_argument(
        '--order', '-o',
        type=int,
        default=3,
        help='Model order (default: 3)'
    )
    
    parser.add_argument(
        '--partitions', '-p',
        type=int,
        default=11,
        help='Number of fuzzy partitions (default: 11)'
    )
    
    parser.add_argument(
        '--mf-type', '-m',
        choices=['triangular', 'gaussian', 'trapezoidal', 'bell'],
        default='triangular',
        help='Membership function type (default: triangular)'
    )
    
    parser.add_argument(
        '--train-ratio', '-t',
        type=float,
        default=0.8,
        help='Training data ratio (default: 0.8)'
    )
    
    args = parser.parse_args()
    
    # File paths
    MACKEY_GLASS_PATH = "/mnt/user-data/uploads/mackey_glass.csv"
    INFLUENZA_PATH = "/mnt/user-data/uploads/Specimens-Train.xlsx"
    
    # Load data based on selection
    print(f"\nLoading {args.dataset} dataset...")
    
    try:
        if args.dataset == 'mackey_glass':
            data = DataLoader.load_mackey_glass(MACKEY_GLASS_PATH)
        else:
            influenza_data = DataLoader.load_influenza_data(INFLUENZA_PATH)
            if args.dataset == 'specimens':
                data = influenza_data['total_specimens']
            elif args.dataset == 'influenza_a':
                data = influenza_data['influenza_a']
            else:
                data = influenza_data['influenza_b']
    except FileNotFoundError as e:
        print(f"Error: Data file not found. {e}")
        print("Please ensure the data files are in the correct location.")
        sys.exit(1)
    
    # Split data
    train_size = int(len(data) * args.train_ratio)
    train_data = data[:train_size]
    
    print(f"Dataset loaded: {len(data)} total samples")
    print(f"Training samples: {train_size}")
    
    # Create and train model
    print(f"\nTraining FTS model...")
    print(f"  Order: {args.order}")
    print(f"  Partitions: {args.partitions}")
    print(f"  MF Type: {args.mf_type}")
    
    predictor = FTSPredictor()
    predictor.load_model_from_config(
        training_data=train_data,
        order=args.order,
        num_partitions=args.partitions,
        mf_type=args.mf_type
    )
    
    info = predictor.get_model_info()
    print(f"  FLRGs generated: {info['num_flrgs']}")
    print(f"\nModel ready!")
    
    # Create and run interactive CLI
    cli = InteractiveCLI(predictor)
    cli.run()


if __name__ == "__main__":
    main()
