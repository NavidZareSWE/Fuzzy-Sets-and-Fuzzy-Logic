"""
Fuzzy Time Series User Interface Module
========================================
This module provides an interactive interface for users to enter
historical data and get predictions from trained FTS models.
"""

import numpy as np
from typing import List, Optional, Dict, Any
import json
import os

from fts_core import FuzzyTimeSeries, MembershipFunctionType, FTSMetrics


class FTSPredictor:
    """
    Interactive predictor interface for FTS models.
    Allows users to input historical data and get predictions.
    """
    
    def __init__(self, model: Optional[FuzzyTimeSeries] = None):
        """
        Initialize the predictor with an optional pre-trained model.
        
        Args:
            model: Pre-trained FuzzyTimeSeries model (optional)
        """
        self.model = model
        self.model_info: Dict[str, Any] = {}
        
    def load_model_from_config(
        self,
        training_data: np.ndarray,
        order: int,
        num_partitions: int,
        mf_type: str = "triangular"
    ) -> 'FTSPredictor':
        """
        Create and train a model with specified configuration.
        
        Args:
            training_data: Historical data to train on
            order: Order of the FTS model
            num_partitions: Number of fuzzy set partitions
            mf_type: Type of membership function
            
        Returns:
            self for method chaining
        """
        mf_type_enum = MembershipFunctionType(mf_type.lower())
        
        self.model = FuzzyTimeSeries(
            order=order,
            num_partitions=num_partitions,
            mf_type=mf_type_enum
        )
        self.model.fit(training_data)
        
        self.model_info = {
            'order': order,
            'num_partitions': num_partitions,
            'mf_type': mf_type,
            'training_size': len(training_data),
            'universe_lower': self.model.universe.lower_bound,
            'universe_upper': self.model.universe.upper_bound,
            'num_flrgs': len(self.model.flrgs)
        }
        
        return self
    
    def predict_next(self, history: List[float]) -> Dict[str, Any]:
        """
        Predict the next value given historical data.
        
        Args:
            history: List of n most recent historical values
                    (n must be >= model order)
        
        Returns:
            Dictionary containing:
            - 'prediction': The predicted next value
            - 'fuzzified_input': The fuzzified recent values
            - 'matched_flrg': The matched FLRG (if any)
        """
        if self.model is None:
            raise ValueError("No model loaded. Train a model first.")
        
        if len(history) < self.model.order:
            raise ValueError(
                f"History length ({len(history)}) must be >= model order ({self.model.order})"
            )
        
        # Get the last 'order' values
        recent = history[-self.model.order:]
        
        # Fuzzify input
        fuzzified = tuple(self.model._fuzzify_value(v) for v in recent)
        
        # Get prediction
        prediction = self.model.predict_next(history)
        
        # Get matched FLRG
        matched_flrg = None
        if fuzzified in self.model.flrgs:
            matched_flrg = str(self.model.flrgs[fuzzified])
        
        return {
            'prediction': prediction,
            'input_values': recent,
            'fuzzified_input': list(fuzzified),
            'matched_flrg': matched_flrg
        }
    
    def predict_multiple(self, history: List[float], steps: int = 1) -> List[Dict[str, Any]]:
        """
        Predict multiple future values.
        
        Args:
            history: Historical data
            steps: Number of steps to forecast
            
        Returns:
            List of prediction results
        """
        if self.model is None:
            raise ValueError("No model loaded. Train a model first.")
        
        results = []
        current_history = list(history)
        
        for step in range(steps):
            result = self.predict_next(current_history)
            result['step'] = step + 1
            results.append(result)
            
            # Add prediction to history for next step
            current_history.append(result['prediction'])
        
        return results
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about the loaded model."""
        if self.model is None:
            return {'status': 'No model loaded'}
        
        return {
            **self.model_info,
            'fuzzy_sets': self.model.get_fuzzy_sets_info(),
            'num_flrgs': len(self.model.flrgs),
            'status': 'Model loaded and ready'
        }
    
    def get_flrgs(self) -> List[str]:
        """Get all FLRGs as strings."""
        if self.model is None:
            return []
        return self.model.get_flrgs_as_strings()


class InteractiveCLI:
    """
    Command-line interface for interactive FTS predictions.
    """
    
    def __init__(self, predictor: FTSPredictor):
        """
        Initialize the CLI.
        
        Args:
            predictor: FTSPredictor instance with a trained model
        """
        self.predictor = predictor
        
    def run(self):
        """Run the interactive CLI session."""
        print("\n" + "="*60)
        print("FUZZY TIME SERIES PREDICTION INTERFACE")
        print("="*60)
        
        # Display model info
        info = self.predictor.get_model_info()
        print(f"\nModel Configuration:")
        print(f"  Order: {info.get('order', 'N/A')}")
        print(f"  Partitions: {info.get('num_partitions', 'N/A')}")
        print(f"  MF Type: {info.get('mf_type', 'N/A')}")
        print(f"  Number of FLRGs: {info.get('num_flrgs', 'N/A')}")
        
        if self.predictor.model:
            min_input = self.predictor.model.order
            print(f"\nMinimum required input values: {min_input}")
        
        print("\nCommands:")
        print("  'predict' or 'p' - Enter values and get prediction")
        print("  'multi' or 'm' - Predict multiple steps ahead")
        print("  'flrgs' or 'f' - Show all Fuzzy Logical Relation Groups")
        print("  'info' or 'i' - Show model information")
        print("  'help' or 'h' - Show this help message")
        print("  'quit' or 'q' - Exit the program")
        
        while True:
            try:
                command = input("\n> Enter command: ").strip().lower()
                
                if command in ['quit', 'q', 'exit']:
                    print("Goodbye!")
                    break
                    
                elif command in ['help', 'h']:
                    self._show_help()
                    
                elif command in ['predict', 'p']:
                    self._single_prediction()
                    
                elif command in ['multi', 'm']:
                    self._multi_prediction()
                    
                elif command in ['flrgs', 'f']:
                    self._show_flrgs()
                    
                elif command in ['info', 'i']:
                    self._show_info()
                    
                else:
                    print("Unknown command. Type 'help' for available commands.")
                    
            except KeyboardInterrupt:
                print("\nGoodbye!")
                break
            except Exception as e:
                print(f"Error: {e}")
    
    def _show_help(self):
        """Display help message."""
        print("\nAvailable Commands:")
        print("-" * 40)
        print("  predict (p)  - Make a single prediction")
        print("  multi (m)    - Forecast multiple steps")
        print("  flrgs (f)    - Display all FLRGs")
        print("  info (i)     - Show model details")
        print("  help (h)     - Show this message")
        print("  quit (q)     - Exit the program")
        
    def _single_prediction(self):
        """Handle single prediction request."""
        if not self.predictor.model:
            print("No model loaded!")
            return
            
        order = self.predictor.model.order
        print(f"\nEnter at least {order} historical values (comma-separated):")
        
        try:
            user_input = input("> Values: ")
            values = [float(v.strip()) for v in user_input.split(',')]
            
            if len(values) < order:
                print(f"Error: Need at least {order} values, got {len(values)}")
                return
            
            result = self.predictor.predict_next(values)
            
            print("\n" + "-"*40)
            print("PREDICTION RESULT")
            print("-"*40)
            print(f"Input values: {result['input_values']}")
            print(f"Fuzzified as: {result['fuzzified_input']}")
            
            if result['matched_flrg']:
                print(f"Matched FLRG: {result['matched_flrg']}")
            else:
                print("Matched FLRG: (nearest neighbor used)")
                
            print(f"\n>>> PREDICTED NEXT VALUE: {result['prediction']:.6f} <<<")
            
        except ValueError as e:
            print(f"Error parsing input: {e}")
            print("Please enter numeric values separated by commas.")
    
    def _multi_prediction(self):
        """Handle multi-step prediction request."""
        if not self.predictor.model:
            print("No model loaded!")
            return
            
        order = self.predictor.model.order
        print(f"\nEnter at least {order} historical values (comma-separated):")
        
        try:
            user_input = input("> Values: ")
            values = [float(v.strip()) for v in user_input.split(',')]
            
            if len(values) < order:
                print(f"Error: Need at least {order} values, got {len(values)}")
                return
            
            steps_input = input("> Number of steps to forecast: ")
            steps = int(steps_input)
            
            if steps < 1:
                print("Error: Steps must be at least 1")
                return
            
            results = self.predictor.predict_multiple(values, steps)
            
            print("\n" + "-"*40)
            print(f"MULTI-STEP FORECAST ({steps} steps)")
            print("-"*40)
            
            for r in results:
                print(f"Step {r['step']}: {r['prediction']:.6f}")
            
            print("-"*40)
            predictions = [r['prediction'] for r in results]
            print(f"All predictions: {[f'{p:.4f}' for p in predictions]}")
            
        except ValueError as e:
            print(f"Error: {e}")
    
    def _show_flrgs(self):
        """Display all FLRGs."""
        flrgs = self.predictor.get_flrgs()
        
        print("\n" + "-"*50)
        print("FUZZY LOGICAL RELATION GROUPS (FLRGs)")
        print("-"*50)
        
        if not flrgs:
            print("No FLRGs available.")
            return
        
        for i, flrg in enumerate(flrgs, 1):
            print(f"  {i:3d}. {flrg}")
        
        print("-"*50)
        print(f"Total FLRGs: {len(flrgs)}")
    
    def _show_info(self):
        """Display model information."""
        info = self.predictor.get_model_info()
        
        print("\n" + "-"*50)
        print("MODEL INFORMATION")
        print("-"*50)
        
        for key, value in info.items():
            if key != 'fuzzy_sets':
                print(f"  {key}: {value}")
        
        if 'fuzzy_sets' in info:
            print("\n  Fuzzy Sets:")
            for fs in info['fuzzy_sets']:
                print(f"    - {fs['name']}: center={fs['center']:.4f}")


def create_prediction_interface(
    training_data: np.ndarray,
    order: int = 1,
    num_partitions: int = 7,
    mf_type: str = "triangular"
) -> InteractiveCLI:
    """
    Create an interactive prediction interface with a trained model.
    
    Args:
        training_data: Data to train the model on
        order: Model order
        num_partitions: Number of fuzzy partitions
        mf_type: Membership function type
        
    Returns:
        InteractiveCLI instance ready to run
    """
    predictor = FTSPredictor()
    predictor.load_model_from_config(
        training_data=training_data,
        order=order,
        num_partitions=num_partitions,
        mf_type=mf_type
    )
    
    return InteractiveCLI(predictor)


class WebInterface:
    """
    Simple web-based interface using Flask (optional).
    This provides a REST API for predictions.
    """
    
    def __init__(self, predictor: FTSPredictor, host: str = '0.0.0.0', port: int = 5000):
        self.predictor = predictor
        self.host = host
        self.port = port
        self.app = None
        
    def create_app(self):
        """Create Flask application."""
        try:
            from flask import Flask, request, jsonify, render_template_string
        except ImportError:
            print("Flask not installed. Install with: pip install flask")
            return None
        
        self.app = Flask(__name__)
        
        # HTML template for the web interface
        html_template = '''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Fuzzy Time Series Predictor</title>
            <style>
                body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
                .container { background: #f5f5f5; padding: 20px; border-radius: 10px; }
                input, button { padding: 10px; margin: 5px; }
                input[type="text"] { width: 300px; }
                button { background: #4CAF50; color: white; border: none; cursor: pointer; }
                button:hover { background: #45a049; }
                .result { background: #e7f3ff; padding: 15px; margin-top: 20px; border-radius: 5px; }
                .error { background: #ffebee; color: #c62828; }
                h1 { color: #333; }
                .info { background: #fff9c4; padding: 10px; border-radius: 5px; margin-bottom: 20px; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Fuzzy Time Series Predictor</h1>
                <div class="info" id="model-info"></div>
                
                <h3>Enter Historical Values</h3>
                <p>Enter comma-separated numerical values:</p>
                <input type="text" id="values" placeholder="e.g., 1.2, 1.5, 1.3, 1.4">
                <br>
                <input type="number" id="steps" value="1" min="1" max="10" style="width: 100px;">
                <label>steps ahead</label>
                <br><br>
                <button onclick="predict()">Predict</button>
                
                <div id="result" class="result" style="display:none;"></div>
            </div>
            
            <script>
                // Load model info on page load
                fetch('/api/info')
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('model-info').innerHTML = 
                            `<strong>Model:</strong> Order=${data.order}, 
                             Partitions=${data.num_partitions}, 
                             Type=${data.mf_type}, 
                             FLRGs=${data.num_flrgs}`;
                    });
                
                function predict() {
                    const values = document.getElementById('values').value;
                    const steps = document.getElementById('steps').value;
                    
                    fetch('/api/predict', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({values: values, steps: parseInt(steps)})
                    })
                    .then(response => response.json())
                    .then(data => {
                        const resultDiv = document.getElementById('result');
                        resultDiv.style.display = 'block';
                        
                        if (data.error) {
                            resultDiv.className = 'result error';
                            resultDiv.innerHTML = `<strong>Error:</strong> ${data.error}`;
                        } else {
                            resultDiv.className = 'result';
                            let html = '<h4>Prediction Results</h4>';
                            data.predictions.forEach((p, i) => {
                                html += `<p><strong>Step ${i+1}:</strong> ${p.prediction.toFixed(6)}</p>`;
                            });
                            resultDiv.innerHTML = html;
                        }
                    });
                }
            </script>
        </body>
        </html>
        '''
        
        @self.app.route('/')
        def home():
            return render_template_string(html_template)
        
        @self.app.route('/api/info')
        def get_info():
            return jsonify(self.predictor.get_model_info())
        
        @self.app.route('/api/predict', methods=['POST'])
        def predict():
            try:
                data = request.get_json()
                values_str = data.get('values', '')
                steps = data.get('steps', 1)
                
                values = [float(v.strip()) for v in values_str.split(',') if v.strip()]
                
                if len(values) < self.predictor.model.order:
                    return jsonify({
                        'error': f'Need at least {self.predictor.model.order} values'
                    })
                
                results = self.predictor.predict_multiple(values, steps)
                return jsonify({'predictions': results})
                
            except Exception as e:
                return jsonify({'error': str(e)})
        
        @self.app.route('/api/flrgs')
        def get_flrgs():
            return jsonify({'flrgs': self.predictor.get_flrgs()})
        
        return self.app
    
    def run(self):
        """Run the web server."""
        if self.app is None:
            self.create_app()
        
        if self.app:
            print(f"\nStarting web interface at http://{self.host}:{self.port}")
            self.app.run(host=self.host, port=self.port, debug=False)
